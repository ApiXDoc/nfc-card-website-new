<?php
/**
 * Products API Endpoints
 * Handles all product-related operations
 */

require_once '../config/database.php';

setCorsHeaders();

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$request_uri = $_SERVER['REQUEST_URI'];
$path_parts = explode('/', trim(parse_url($request_uri, PHP_URL_PATH), '/'));

try {
    switch ($method) {
        case 'GET':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                // Get single product by ID or slug
                getProductById($db, $path_parts[3]);
            } else {
                // Get all products with filters and pagination
                getAllProducts($db);
            }
            break;
            
        case 'POST':
            createProduct($db);
            break;
            
        case 'PUT':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                updateProduct($db, $path_parts[3]);
            } else {
                errorResponse("Product ID required for update", 400);
            }
            break;
            
        case 'DELETE':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                deleteProduct($db, $path_parts[3]);
            } else {
                errorResponse("Product ID required for deletion", 400);
            }
            break;
            
        default:
            errorResponse("Method not allowed", 405);
            break;
    }
} catch (Exception $e) {
    error_log("Products API Error: " . $e->getMessage());
    errorResponse("Internal server error", 500);
}

/**
 * Get all products with filters and pagination
 */
function getAllProducts($db) {
    $pagination = getPaginationParams();
    $where_conditions = [];
    $params = [];
    
    // Base query
    $base_query = "FROM active_products_view p WHERE 1=1";
    
    // Category filter
    if (isset($_GET['category']) && !empty($_GET['category'])) {
        $where_conditions[] = "p.category_id = :category_id";
        $params[':category_id'] = $_GET['category'];
    }
    
    // Featured filter
    if (isset($_GET['featured']) && $_GET['featured'] === 'true') {
        $where_conditions[] = "p.featured = 1";
    }
    
    // In stock filter
    if (isset($_GET['in_stock']) && $_GET['in_stock'] === 'true') {
        $where_conditions[] = "p.is_in_stock = 1";
    }
    
    // Price range filter
    if (isset($_GET['min_price']) && is_numeric($_GET['min_price'])) {
        $where_conditions[] = "p.price >= :min_price";
        $params[':min_price'] = $_GET['min_price'];
    }
    
    if (isset($_GET['max_price']) && is_numeric($_GET['max_price'])) {
        $where_conditions[] = "p.price <= :max_price";
        $params[':max_price'] = $_GET['max_price'];
    }
    
    // Search filter
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $where_conditions[] = "(p.name LIKE :search OR p.description LIKE :search OR p.short_description LIKE :search)";
        $params[':search'] = '%' . $_GET['search'] . '%';
    }
    
    // Add WHERE conditions
    if (!empty($where_conditions)) {
        $base_query .= " AND " . implode(" AND ", $where_conditions);
    }
    
    // Count total records
    $count_query = "SELECT COUNT(*) as total " . $base_query;
    $count_stmt = $db->prepare($count_query);
    $count_stmt->execute($params);
    $total = $count_stmt->fetch()['total'];
    
    // Get products with pagination
    $sort_by = isset($_GET['sort']) ? $_GET['sort'] : 'created_at';
    $sort_order = isset($_GET['order']) && strtoupper($_GET['order']) === 'ASC' ? 'ASC' : 'DESC';
    
    // Validate sort field
    $allowed_sort_fields = ['name', 'price', 'rating', 'created_at', 'featured', 'total_sales'];
    if (!in_array($sort_by, $allowed_sort_fields)) {
        $sort_by = 'created_at';
    }
    
    $query = "SELECT p.*, 
                     (SELECT GROUP_CONCAT(pf.feature_text ORDER BY pf.sort_order) 
                      FROM product_features pf 
                      WHERE pf.product_id = p.id) as features
              " . $base_query . "
              ORDER BY p.{$sort_by} {$sort_order}
              LIMIT :limit OFFSET :offset";
    
    $stmt = $db->prepare($query);
    
    // Bind pagination parameters
    $stmt->bindValue(':limit', $pagination['limit'], PDO::PARAM_INT);
    $stmt->bindValue(':offset', $pagination['offset'], PDO::PARAM_INT);
    
    // Bind other parameters
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    $stmt->execute();
    $products = $stmt->fetchAll();
    
    // Process features for each product
    foreach ($products as &$product) {
        $product['features'] = $product['features'] ? explode(',', $product['features']) : [];
        $product['price'] = floatval($product['price']);
        $product['original_price'] = $product['original_price'] ? floatval($product['original_price']) : null;
        $product['rating'] = floatval($product['rating']);
        $product['featured'] = (bool)$product['featured'];
        $product['is_in_stock'] = (bool)$product['is_in_stock'];
    }
    
    $response = buildPaginationResponse($products, $total, $pagination['page'], $pagination['limit']);
    successResponse($response, "Products retrieved successfully");
}

/**
 * Get single product by ID or slug
 */
function getProductById($db, $identifier) {
    // Check if identifier is numeric (ID) or string (slug)
    $field = is_numeric($identifier) ? 'id' : 'slug';
    
    $query = "SELECT p.*,
                     c.name as category_name,
                     c.slug as category_slug,
                     (SELECT GROUP_CONCAT(pf.feature_text ORDER BY pf.sort_order) 
                      FROM product_features pf 
                      WHERE pf.product_id = p.id) as features
              FROM products p
              LEFT JOIN categories c ON p.category_id = c.id
              WHERE p.{$field} = :identifier AND p.is_active = 1";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':identifier', $identifier);
    $stmt->execute();
    
    $product = $stmt->fetch();
    
    if (!$product) {
        errorResponse("Product not found", 404);
    }
    
    // Get product images
    $images_query = "SELECT image_url, alt_text, is_primary, sort_order 
                     FROM product_images 
                     WHERE product_id = :product_id 
                     ORDER BY is_primary DESC, sort_order ASC";
    
    $images_stmt = $db->prepare($images_query);
    $images_stmt->bindParam(':product_id', $product['id']);
    $images_stmt->execute();
    $product['images'] = $images_stmt->fetchAll();
    
    // Get product reviews
    $reviews_query = "SELECT pr.*, 
                             DATE_FORMAT(pr.created_at, '%Y-%m-%d %H:%i:%s') as review_date
                      FROM product_reviews pr 
                      WHERE pr.product_id = :product_id AND pr.is_approved = 1 
                      ORDER BY pr.created_at DESC 
                      LIMIT 10";
    
    $reviews_stmt = $db->prepare($reviews_query);
    $reviews_stmt->bindParam(':product_id', $product['id']);
    $reviews_stmt->execute();
    $product['reviews'] = $reviews_stmt->fetchAll();
    
    // Process data
    $product['features'] = $product['features'] ? explode(',', $product['features']) : [];
    $product['price'] = floatval($product['price']);
    $product['original_price'] = $product['original_price'] ? floatval($product['original_price']) : null;
    $product['rating'] = floatval($product['rating']);
    $product['featured'] = (bool)$product['featured'];
    $product['is_in_stock'] = (bool)$product['is_in_stock'];
    
    foreach ($product['images'] as &$image) {
        $image['is_primary'] = (bool)$image['is_primary'];
    }
    
    foreach ($product['reviews'] as &$review) {
        $review['rating'] = intval($review['rating']);
        $review['is_verified'] = (bool)$review['is_verified'];
        $review['helpful_count'] = intval($review['helpful_count']);
    }
    
    successResponse($product, "Product retrieved successfully");
}

/**
 * Create new product
 */
function createProduct($db) {
    $data = getInputData();
    $required_fields = ['name', 'description', 'price', 'category_id'];
    validateRequired($data, $required_fields);
    
    $data = sanitizeInput($data);
    
    try {
        $db->beginTransaction();
        
        $product_id = generateUUID();
        $slug = generateSlug($data['name']);
        
        // Check if slug exists
        $slug_check = "SELECT COUNT(*) FROM products WHERE slug = :slug";
        $slug_stmt = $db->prepare($slug_check);
        $slug_stmt->bindParam(':slug', $slug);
        $slug_stmt->execute();
        
        if ($slug_stmt->fetchColumn() > 0) {
            $slug .= '-' . time();
        }
        
        $query = "INSERT INTO products (
                    id, name, slug, description, short_description, price, original_price,
                    sku, category_id, stock_quantity, is_in_stock, weight, dimensions,
                    meta_title, meta_description, featured
                  ) VALUES (
                    :id, :name, :slug, :description, :short_description, :price, :original_price,
                    :sku, :category_id, :stock_quantity, :is_in_stock, :weight, :dimensions,
                    :meta_title, :meta_description, :featured
                  )";
        
        $stmt = $db->prepare($query);
        
        $stmt->bindParam(':id', $product_id);
        $stmt->bindParam(':name', $data['name']);
        $stmt->bindParam(':slug', $slug);
        $stmt->bindParam(':description', $data['description']);
        $stmt->bindParam(':short_description', $data['short_description'] ?? null);
        $stmt->bindParam(':price', $data['price']);
        $stmt->bindParam(':original_price', $data['original_price'] ?? null);
        $stmt->bindParam(':sku', $data['sku'] ?? null);
        $stmt->bindParam(':category_id', $data['category_id']);
        $stmt->bindParam(':stock_quantity', $data['stock_quantity'] ?? 0);
        $stmt->bindParam(':is_in_stock', $data['is_in_stock'] ?? true, PDO::PARAM_BOOL);
        $stmt->bindParam(':weight', $data['weight'] ?? null);
        $stmt->bindParam(':dimensions', $data['dimensions'] ?? null);
        $stmt->bindParam(':meta_title', $data['meta_title'] ?? null);
        $stmt->bindParam(':meta_description', $data['meta_description'] ?? null);
        $stmt->bindParam(':featured', $data['featured'] ?? false, PDO::PARAM_BOOL);
        
        $stmt->execute();
        
        // Add features if provided
        if (isset($data['features']) && is_array($data['features'])) {
            $features_query = "INSERT INTO product_features (product_id, feature_text, sort_order) VALUES (?, ?, ?)";
            $features_stmt = $db->prepare($features_query);
            
            foreach ($data['features'] as $index => $feature) {
                $features_stmt->execute([$product_id, $feature, $index + 1]);
            }
        }
        
        // Add images if provided
        if (isset($data['images']) && is_array($data['images'])) {
            $images_query = "INSERT INTO product_images (product_id, image_url, alt_text, is_primary, sort_order) VALUES (?, ?, ?, ?, ?)";
            $images_stmt = $db->prepare($images_query);
            
            foreach ($data['images'] as $index => $image) {
                $images_stmt->execute([
                    $product_id,
                    $image['url'],
                    $image['alt'] ?? '',
                    $index === 0 ? 1 : 0,
                    $index + 1
                ]);
            }
        }
        
        $db->commit();
        
        successResponse(['id' => $product_id], "Product created successfully");
        
    } catch (Exception $e) {
        $db->rollBack();
        error_log("Create product error: " . $e->getMessage());
        errorResponse("Failed to create product", 500);
    }
}

/**
 * Update product
 */
function updateProduct($db, $product_id) {
    $data = getInputData();
    $data = sanitizeInput($data);
    
    try {
        $db->beginTransaction();
        
        // Check if product exists
        $check_query = "SELECT id FROM products WHERE id = :id";
        $check_stmt = $db->prepare($check_query);
        $check_stmt->bindParam(':id', $product_id);
        $check_stmt->execute();
        
        if (!$check_stmt->fetch()) {
            errorResponse("Product not found", 404);
        }
        
        // Build update query dynamically
        $update_fields = [];
        $params = [':id' => $product_id];
        
        $allowed_fields = [
            'name', 'description', 'short_description', 'price', 'original_price',
            'sku', 'category_id', 'stock_quantity', 'is_in_stock', 'weight',
            'dimensions', 'meta_title', 'meta_description', 'featured'
        ];
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                $update_fields[] = "$field = :$field";
                $params[":$field"] = $data[$field];
            }
        }
        
        if (!empty($update_fields)) {
            $query = "UPDATE products SET " . implode(', ', $update_fields) . " WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->execute($params);
        }
        
        // Update features if provided
        if (isset($data['features']) && is_array($data['features'])) {
            // Delete existing features
            $delete_features = "DELETE FROM product_features WHERE product_id = ?";
            $db->prepare($delete_features)->execute([$product_id]);
            
            // Add new features
            $features_query = "INSERT INTO product_features (product_id, feature_text, sort_order) VALUES (?, ?, ?)";
            $features_stmt = $db->prepare($features_query);
            
            foreach ($data['features'] as $index => $feature) {
                $features_stmt->execute([$product_id, $feature, $index + 1]);
            }
        }
        
        $db->commit();
        
        successResponse([], "Product updated successfully");
        
    } catch (Exception $e) {
        $db->rollBack();
        error_log("Update product error: " . $e->getMessage());
        errorResponse("Failed to update product", 500);
    }
}

/**
 * Delete product (soft delete)
 */
function deleteProduct($db, $product_id) {
    try {
        $query = "UPDATE products SET is_active = 0 WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $product_id);
        
        if ($stmt->execute() && $stmt->rowCount() > 0) {
            successResponse([], "Product deleted successfully");
        } else {
            errorResponse("Product not found", 404);
        }
        
    } catch (Exception $e) {
        error_log("Delete product error: " . $e->getMessage());
        errorResponse("Failed to delete product", 500);
    }
}

/**
 * Generate URL-friendly slug
 */
function generateSlug($string) {
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $string)));
    return trim($slug, '-');
}
?>

<?php
/**
 * Contact & FAQ API Endpoints
 * Handles contact messages and FAQ management
 */

require_once '../config/database.php';

setCorsHeaders();

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$request_uri = $_SERVER['REQUEST_URI'];
$path_parts = explode('/', trim(parse_url($request_uri, PHP_URL_PATH), '/'));

try {
    // Determine if this is FAQ or Contact endpoint
    if (isset($path_parts[2])) {
        if ($path_parts[2] === 'faq') {
            handleFAQ($db, $method, $path_parts);
        } elseif ($path_parts[2] === 'contact') {
            handleContact($db, $method, $path_parts);
        } else {
            errorResponse("Invalid endpoint", 404);
        }
    } else {
        errorResponse("Endpoint not specified", 400);
    }
} catch (Exception $e) {
    error_log("Contact/FAQ API Error: " . $e->getMessage());
    errorResponse("Internal server error", 500);
}

/**
 * Handle FAQ endpoints
 */
function handleFAQ($db, $method, $path_parts) {
    switch ($method) {
        case 'GET':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                getFAQById($db, $path_parts[3]);
            } else {
                getAllFAQs($db);
            }
            break;
            
        case 'POST':
            createFAQ($db);
            break;
            
        case 'PUT':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                updateFAQ($db, $path_parts[3]);
            } else {
                errorResponse("FAQ ID required for update", 400);
            }
            break;
            
        case 'DELETE':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                deleteFAQ($db, $path_parts[3]);
            } else {
                errorResponse("FAQ ID required for deletion", 400);
            }
            break;
            
        default:
            errorResponse("Method not allowed", 405);
            break;
    }
}

/**
 * Handle Contact endpoints
 */
function handleContact($db, $method, $path_parts) {
    switch ($method) {
        case 'GET':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                getContactMessageById($db, $path_parts[3]);
            } else {
                getAllContactMessages($db);
            }
            break;
            
        case 'POST':
            createContactMessage($db);
            break;
            
        case 'PUT':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                updateContactMessage($db, $path_parts[3]);
            } else {
                errorResponse("Message ID required for update", 400);
            }
            break;
            
        case 'DELETE':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                deleteContactMessage($db, $path_parts[3]);
            } else {
                errorResponse("Message ID required for deletion", 400);
            }
            break;
            
        default:
            errorResponse("Method not allowed", 405);
            break;
    }
}

/**
 * Get all FAQs with filtering
 */
function getAllFAQs($db) {
    $pagination = getPaginationParams();
    $where_conditions = ["f.is_active = 1"];
    $params = [];
    
    // Category filter
    if (isset($_GET['category']) && !empty($_GET['category'])) {
        $where_conditions[] = "f.category = :category";
        $params[':category'] = $_GET['category'];
    }
    
    // Search filter
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $where_conditions[] = "(f.question LIKE :search OR f.answer LIKE :search)";
        $params[':search'] = '%' . $_GET['search'] . '%';
    }
    
    $where_clause = implode(" AND ", $where_conditions);
    
    // Count total records
    $count_query = "SELECT COUNT(*) as total FROM faq f WHERE {$where_clause}";
    $count_stmt = $db->prepare($count_query);
    $count_stmt->execute($params);
    $total = $count_stmt->fetch()['total'];
    
    // Get FAQs with pagination
    $sort_by = isset($_GET['sort']) ? $_GET['sort'] : 'sort_order';
    $sort_order = isset($_GET['order']) && strtoupper($_GET['order']) === 'DESC' ? 'DESC' : 'ASC';
    
    $allowed_sort_fields = ['category', 'sort_order', 'view_count', 'helpful_count', 'created_at'];
    if (!in_array($sort_by, $allowed_sort_fields)) {
        $sort_by = 'sort_order';
    }
    
    $query = "SELECT f.* FROM faq f 
              WHERE {$where_clause}
              ORDER BY f.category ASC, f.{$sort_by} {$sort_order}
              LIMIT :limit OFFSET :offset";
    
    $stmt = $db->prepare($query);
    
    // Bind pagination parameters
    $stmt->bindValue(':limit', $pagination['limit'], PDO::PARAM_INT);
    $stmt->bindValue(':offset', $pagination['offset'], PDO::PARAM_INT);
    
    // Bind other parameters
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    $stmt->execute();
    $faqs = $stmt->fetchAll();
    
    // Group by category
    $grouped_faqs = [];
    foreach ($faqs as $faq) {
        $category = $faq['category'];
        if (!isset($grouped_faqs[$category])) {
            $grouped_faqs[$category] = [];
        }
        
        $faq['view_count'] = intval($faq['view_count']);
        $faq['helpful_count'] = intval($faq['helpful_count']);
        $faq['sort_order'] = intval($faq['sort_order']);
        
        $grouped_faqs[$category][] = $faq;
    }
    
    $response = [
        'faqs_by_category' => $grouped_faqs,
        'pagination' => [
            'current_page' => $pagination['page'],
            'total_pages' => ceil($total / $pagination['limit']),
            'per_page' => $pagination['limit'],
            'total_items' => $total
        ]
    ];
    
    successResponse($response, "FAQs retrieved successfully");
}

/**
 * Get FAQ by ID
 */
function getFAQById($db, $faq_id) {
    $query = "SELECT * FROM faq WHERE id = :id AND is_active = 1";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $faq_id);
    $stmt->execute();
    
    $faq = $stmt->fetch();
    
    if (!$faq) {
        errorResponse("FAQ not found", 404);
    }
    
    // Increment view count
    $update_views = "UPDATE faq SET view_count = view_count + 1 WHERE id = :id";
    $update_stmt = $db->prepare($update_views);
    $update_stmt->bindParam(':id', $faq_id);
    $update_stmt->execute();
    
    $faq['view_count'] = intval($faq['view_count']) + 1;
    $faq['helpful_count'] = intval($faq['helpful_count']);
    $faq['sort_order'] = intval($faq['sort_order']);
    
    successResponse($faq, "FAQ retrieved successfully");
}

/**
 * Create new FAQ
 */
function createFAQ($db) {
    $data = getInputData();
    $required_fields = ['category', 'question', 'answer'];
    validateRequired($data, $required_fields);
    
    $data = sanitizeInput($data);
    
    try {
        $query = "INSERT INTO faq (category, question, answer, sort_order, is_active) 
                  VALUES (:category, :question, :answer, :sort_order, :is_active)";
        
        $stmt = $db->prepare($query);
        $stmt->execute([
            ':category' => $data['category'],
            ':question' => $data['question'],
            ':answer' => $data['answer'],
            ':sort_order' => $data['sort_order'] ?? 0,
            ':is_active' => $data['is_active'] ?? true
        ]);
        
        $faq_id = $db->lastInsertId();
        
        successResponse(['faq_id' => $faq_id], "FAQ created successfully");
        
    } catch (Exception $e) {
        error_log("Create FAQ error: " . $e->getMessage());
        errorResponse("Failed to create FAQ", 500);
    }
}

/**
 * Update FAQ
 */
function updateFAQ($db, $faq_id) {
    $data = getInputData();
    $data = sanitizeInput($data);
    
    try {
        // Check if FAQ exists
        $check_query = "SELECT id FROM faq WHERE id = :id";
        $check_stmt = $db->prepare($check_query);
        $check_stmt->bindParam(':id', $faq_id);
        $check_stmt->execute();
        
        if (!$check_stmt->fetch()) {
            errorResponse("FAQ not found", 404);
        }
        
        // Build update query dynamically
        $update_fields = [];
        $params = [':id' => $faq_id];
        
        $allowed_fields = ['category', 'question', 'answer', 'sort_order', 'is_active'];
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                $update_fields[] = "$field = :$field";
                $params[":$field"] = $data[$field];
            }
        }
        
        if (empty($update_fields)) {
            errorResponse("No valid fields to update", 400);
        }
        
        $query = "UPDATE faq SET " . implode(', ', $update_fields) . " WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->execute($params);
        
        successResponse([], "FAQ updated successfully");
        
    } catch (Exception $e) {
        error_log("Update FAQ error: " . $e->getMessage());
        errorResponse("Failed to update FAQ", 500);
    }
}

/**
 * Delete FAQ (soft delete)
 */
function deleteFAQ($db, $faq_id) {
    try {
        $query = "UPDATE faq SET is_active = 0 WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $faq_id);
        
        if ($stmt->execute() && $stmt->rowCount() > 0) {
            successResponse([], "FAQ deleted successfully");
        } else {
            errorResponse("FAQ not found", 404);
        }
        
    } catch (Exception $e) {
        error_log("Delete FAQ error: " . $e->getMessage());
        errorResponse("Failed to delete FAQ", 500);
    }
}

/**
 * Get all contact messages with filtering
 */
function getAllContactMessages($db) {
    $pagination = getPaginationParams();
    $where_conditions = [];
    $params = [];
    
    // Status filter
    if (isset($_GET['status']) && !empty($_GET['status'])) {
        $where_conditions[] = "cm.status = :status";
        $params[':status'] = $_GET['status'];
    }
    
    // Type filter
    if (isset($_GET['type']) && !empty($_GET['type'])) {
        $where_conditions[] = "cm.type = :type";
        $params[':type'] = $_GET['type'];
    }
    
    // Priority filter
    if (isset($_GET['priority']) && !empty($_GET['priority'])) {
        $where_conditions[] = "cm.priority = :priority";
        $params[':priority'] = $_GET['priority'];
    }
    
    // Search filter
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $where_conditions[] = "(cm.name LIKE :search OR cm.email LIKE :search OR cm.subject LIKE :search OR cm.message LIKE :search)";
        $params[':search'] = '%' . $_GET['search'] . '%';
    }
    
    // Date range filter
    if (isset($_GET['start_date']) && !empty($_GET['start_date'])) {
        $where_conditions[] = "DATE(cm.created_at) >= :start_date";
        $params[':start_date'] = $_GET['start_date'];
    }
    
    if (isset($_GET['end_date']) && !empty($_GET['end_date'])) {
        $where_conditions[] = "DATE(cm.created_at) <= :end_date";
        $params[':end_date'] = $_GET['end_date'];
    }
    
    $where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";
    
    // Count total records
    $count_query = "SELECT COUNT(*) as total FROM contact_messages cm {$where_clause}";
    $count_stmt = $db->prepare($count_query);
    $count_stmt->execute($params);
    $total = $count_stmt->fetch()['total'];
    
    // Get messages with pagination
    $sort_by = isset($_GET['sort']) ? $_GET['sort'] : 'created_at';
    $sort_order = isset($_GET['order']) && strtoupper($_GET['order']) === 'ASC' ? 'ASC' : 'DESC';
    
    $allowed_sort_fields = ['name', 'email', 'subject', 'type', 'status', 'priority', 'created_at'];
    if (!in_array($sort_by, $allowed_sort_fields)) {
        $sort_by = 'created_at';
    }
    
    $query = "SELECT cm.* FROM contact_messages cm 
              {$where_clause}
              ORDER BY cm.{$sort_by} {$sort_order}
              LIMIT :limit OFFSET :offset";
    
    $stmt = $db->prepare($query);
    
    // Bind pagination parameters
    $stmt->bindValue(':limit', $pagination['limit'], PDO::PARAM_INT);
    $stmt->bindValue(':offset', $pagination['offset'], PDO::PARAM_INT);
    
    // Bind other parameters
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    $stmt->execute();
    $messages = $stmt->fetchAll();
    
    $response = buildPaginationResponse($messages, $total, $pagination['page'], $pagination['limit']);
    successResponse($response, "Contact messages retrieved successfully");
}

/**
 * Get contact message by ID
 */
function getContactMessageById($db, $message_id) {
    $query = "SELECT * FROM contact_messages WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $message_id);
    $stmt->execute();
    
    $message = $stmt->fetch();
    
    if (!$message) {
        errorResponse("Contact message not found", 404);
    }
    
    successResponse($message, "Contact message retrieved successfully");
}

/**
 * Create new contact message
 */
function createContactMessage($db) {
    $data = getInputData();
    $required_fields = ['name', 'email', 'subject', 'message'];
    validateRequired($data, $required_fields);
    
    $data = sanitizeInput($data);
    
    // Validate email format
    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        errorResponse("Invalid email format", 400);
    }
    
    try {
        $query = "INSERT INTO contact_messages (
                    name, email, phone, subject, message, type, priority
                  ) VALUES (
                    :name, :email, :phone, :subject, :message, :type, :priority
                  )";
        
        $stmt = $db->prepare($query);
        $stmt->execute([
            ':name' => $data['name'],
            ':email' => $data['email'],
            ':phone' => $data['phone'] ?? null,
            ':subject' => $data['subject'],
            ':message' => $data['message'],
            ':type' => $data['type'] ?? 'general',
            ':priority' => $data['priority'] ?? 'medium'
        ]);
        
        $message_id = $db->lastInsertId();
        
        successResponse([
            'message_id' => $message_id,
            'auto_response' => 'Thank you for contacting us. We will get back to you within 24 hours.'
        ], "Contact message sent successfully");
        
    } catch (Exception $e) {
        error_log("Create contact message error: " . $e->getMessage());
        errorResponse("Failed to send message", 500);
    }
}

/**
 * Update contact message (admin function)
 */
function updateContactMessage($db, $message_id) {
    $data = getInputData();
    $data = sanitizeInput($data);
    
    try {
        // Check if message exists
        $check_query = "SELECT id FROM contact_messages WHERE id = :id";
        $check_stmt = $db->prepare($check_query);
        $check_stmt->bindParam(':id', $message_id);
        $check_stmt->execute();
        
        if (!$check_stmt->fetch()) {
            errorResponse("Contact message not found", 404);
        }
        
        // Build update query dynamically
        $update_fields = [];
        $params = [':id' => $message_id];
        
        $allowed_fields = ['status', 'priority', 'assigned_to', 'response'];
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                $update_fields[] = "$field = :$field";
                $params[":$field"] = $data[$field];
            }
        }
        
        // Set responded_at if response is provided
        if (isset($data['response']) && !empty($data['response'])) {
            $update_fields[] = "responded_at = NOW()";
        }
        
        if (empty($update_fields)) {
            errorResponse("No valid fields to update", 400);
        }
        
        $query = "UPDATE contact_messages SET " . implode(', ', $update_fields) . " WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->execute($params);
        
        successResponse([], "Contact message updated successfully");
        
    } catch (Exception $e) {
        error_log("Update contact message error: " . $e->getMessage());
        errorResponse("Failed to update message", 500);
    }
}

/**
 * Delete contact message
 */
function deleteContactMessage($db, $message_id) {
    try {
        $query = "DELETE FROM contact_messages WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $message_id);
        
        if ($stmt->execute() && $stmt->rowCount() > 0) {
            successResponse([], "Contact message deleted successfully");
        } else {
            errorResponse("Contact message not found", 404);
        }
        
    } catch (Exception $e) {
        error_log("Delete contact message error: " . $e->getMessage());
        errorResponse("Failed to delete message", 500);
    }
}
?>

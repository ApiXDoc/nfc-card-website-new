<?php
/**
 * Customers API Endpoints
 * Handles customer registration, login, profile management
 */

require_once '../config/database.php';

setCorsHeaders();

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$request_uri = $_SERVER['REQUEST_URI'];
$path_parts = explode('/', trim(parse_url($request_uri, PHP_URL_PATH), '/'));

try {
    switch ($method) {
        case 'GET':
            if (isset($path_parts[3])) {
                if ($path_parts[3] === 'profile') {
                    getCustomerProfile($db);
                } elseif (!empty($path_parts[3])) {
                    getCustomerById($db, $path_parts[3]);
                }
            } else {
                getAllCustomers($db);
            }
            break;
            
        case 'POST':
            if (isset($path_parts[3])) {
                switch ($path_parts[3]) {
                    case 'register':
                        registerCustomer($db);
                        break;
                    case 'login':
                        loginCustomer($db);
                        break;
                    case 'verify-email':
                        verifyEmail($db);
                        break;
                    case 'forgot-password':
                        forgotPassword($db);
                        break;
                    case 'reset-password':
                        resetPassword($db);
                        break;
                    default:
                        errorResponse("Invalid endpoint", 404);
                }
            } else {
                createCustomer($db);
            }
            break;
            
        case 'PUT':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                updateCustomer($db, $path_parts[3]);
            } else {
                errorResponse("Customer ID required for update", 400);
            }
            break;
            
        case 'DELETE':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                deleteCustomer($db, $path_parts[3]);
            } else {
                errorResponse("Customer ID required for deletion", 400);
            }
            break;
            
        default:
            errorResponse("Method not allowed", 405);
            break;
    }
} catch (Exception $e) {
    error_log("Customers API Error: " . $e->getMessage());
    errorResponse("Internal server error", 500);
}

/**
 * Get all customers with pagination
 */
function getAllCustomers($db) {
    $pagination = getPaginationParams();
    $where_conditions = [];
    $params = [];
    
    // Base query
    $base_query = "FROM customers c WHERE c.is_active = 1";
    
    // Search filter
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $where_conditions[] = "(c.first_name LIKE :search OR c.last_name LIKE :search OR c.email LIKE :search)";
        $params[':search'] = '%' . $_GET['search'] . '%';
    }
    
    // Email verified filter
    if (isset($_GET['verified']) && $_GET['verified'] === 'true') {
        $where_conditions[] = "c.email_verified = 1";
    }
    
    // Add WHERE conditions
    if (!empty($where_conditions)) {
        $base_query .= " AND " . implode(" AND ", $where_conditions);
    }
    
    // Count total records
    $count_query = "SELECT COUNT(*) as total " . $base_query;
    $count_stmt = $db->prepare($count_query);
    $count_stmt->execute($params);
    $total = $count_stmt->fetch()['total'];
    
    // Get customers with pagination
    $sort_by = isset($_GET['sort']) ? $_GET['sort'] : 'created_at';
    $sort_order = isset($_GET['order']) && strtoupper($_GET['order']) === 'ASC' ? 'ASC' : 'DESC';
    
    $allowed_sort_fields = ['first_name', 'last_name', 'email', 'created_at', 'last_login'];
    if (!in_array($sort_by, $allowed_sort_fields)) {
        $sort_by = 'created_at';
    }
    
    $query = "SELECT c.id, c.first_name, c.last_name, c.email, c.phone, 
                     c.email_verified, c.last_login, c.created_at,
                     (SELECT COUNT(*) FROM orders WHERE customer_id = c.id AND status NOT IN ('cancelled', 'refunded')) as total_orders,
                     (SELECT SUM(total_amount) FROM orders WHERE customer_id = c.id AND status NOT IN ('cancelled', 'refunded')) as total_spent
              " . $base_query . "
              ORDER BY c.{$sort_by} {$sort_order}
              LIMIT :limit OFFSET :offset";
    
    $stmt = $db->prepare($query);
    
    // Bind pagination parameters
    $stmt->bindValue(':limit', $pagination['limit'], PDO::PARAM_INT);
    $stmt->bindValue(':offset', $pagination['offset'], PDO::PARAM_INT);
    
    // Bind other parameters
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    $stmt->execute();
    $customers = $stmt->fetchAll();
    
    // Process data
    foreach ($customers as &$customer) {
        $customer['email_verified'] = (bool)$customer['email_verified'];
        $customer['total_orders'] = intval($customer['total_orders']);
        $customer['total_spent'] = $customer['total_spent'] ? floatval($customer['total_spent']) : 0;
        // Remove sensitive data
        unset($customer['password_hash']);
    }
    
    $response = buildPaginationResponse($customers, $total, $pagination['page'], $pagination['limit']);
    successResponse($response, "Customers retrieved successfully");
}

/**
 * Get customer by ID
 */
function getCustomerById($db, $customer_id) {
    $query = "SELECT c.id, c.first_name, c.last_name, c.email, c.phone, c.date_of_birth,
                     c.email_verified, c.email_verified_at, c.last_login, c.created_at
              FROM customers c 
              WHERE c.id = :id AND c.is_active = 1";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $customer_id);
    $stmt->execute();
    
    $customer = $stmt->fetch();
    
    if (!$customer) {
        errorResponse("Customer not found", 404);
    }
    
    // Get customer addresses
    $addresses_query = "SELECT * FROM customer_addresses 
                        WHERE customer_id = :customer_id 
                        ORDER BY is_default DESC, created_at DESC";
    
    $addresses_stmt = $db->prepare($addresses_query);
    $addresses_stmt->bindParam(':customer_id', $customer_id);
    $addresses_stmt->execute();
    $customer['addresses'] = $addresses_stmt->fetchAll();
    
    // Get customer order summary
    $orders_query = "SELECT COUNT(*) as total_orders,
                            SUM(total_amount) as total_spent,
                            MAX(created_at) as last_order_date
                     FROM orders 
                     WHERE customer_id = :customer_id AND status NOT IN ('cancelled', 'refunded')";
    
    $orders_stmt = $db->prepare($orders_query);
    $orders_stmt->bindParam(':customer_id', $customer_id);
    $orders_stmt->execute();
    $order_summary = $orders_stmt->fetch();
    
    $customer['order_summary'] = [
        'total_orders' => intval($order_summary['total_orders']),
        'total_spent' => $order_summary['total_spent'] ? floatval($order_summary['total_spent']) : 0,
        'last_order_date' => $order_summary['last_order_date']
    ];
    
    // Process data
    $customer['email_verified'] = (bool)$customer['email_verified'];
    
    foreach ($customer['addresses'] as &$address) {
        $address['is_default'] = (bool)$address['is_default'];
    }
    
    successResponse($customer, "Customer retrieved successfully");
}

/**
 * Register new customer
 */
function registerCustomer($db) {
    $data = getInputData();
    $required_fields = ['first_name', 'last_name', 'email', 'password'];
    validateRequired($data, $required_fields);
    
    $data = sanitizeInput($data);
    
    // Validate email format
    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        errorResponse("Invalid email format", 400);
    }
    
    // Check if email already exists
    $email_check = "SELECT COUNT(*) FROM customers WHERE email = :email";
    $email_stmt = $db->prepare($email_check);
    $email_stmt->bindParam(':email', $data['email']);
    $email_stmt->execute();
    
    if ($email_stmt->fetchColumn() > 0) {
        errorResponse("Email already registered", 409);
    }
    
    try {
        $customer_id = generateUUID();
        $password_hash = password_hash($data['password'], PASSWORD_DEFAULT);
        
        $query = "INSERT INTO customers (
                    id, first_name, last_name, email, phone, password_hash, date_of_birth
                  ) VALUES (
                    :id, :first_name, :last_name, :email, :phone, :password_hash, :date_of_birth
                  )";
        
        $stmt = $db->prepare($query);
        $stmt->execute([
            ':id' => $customer_id,
            ':first_name' => $data['first_name'],
            ':last_name' => $data['last_name'],
            ':email' => $data['email'],
            ':phone' => $data['phone'] ?? null,
            ':password_hash' => $password_hash,
            ':date_of_birth' => $data['date_of_birth'] ?? null
        ]);
        
        // Generate email verification token (in a real app, send email)
        $verification_token = bin2hex(random_bytes(32));
        
        successResponse([
            'customer_id' => $customer_id,
            'verification_token' => $verification_token,
            'message' => 'Registration successful. Please verify your email.'
        ], "Customer registered successfully");
        
    } catch (Exception $e) {
        error_log("Register customer error: " . $e->getMessage());
        errorResponse("Failed to register customer", 500);
    }
}

/**
 * Customer login
 */
function loginCustomer($db) {
    $data = getInputData();
    $required_fields = ['email', 'password'];
    validateRequired($data, $required_fields);
    
    $data = sanitizeInput($data);
    
    $query = "SELECT id, first_name, last_name, email, password_hash, email_verified, is_active
              FROM customers 
              WHERE email = :email";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':email', $data['email']);
    $stmt->execute();
    
    $customer = $stmt->fetch();
    
    if (!$customer || !password_verify($data['password'], $customer['password_hash'])) {
        errorResponse("Invalid email or password", 401);
    }
    
    if (!$customer['is_active']) {
        errorResponse("Account is deactivated", 403);
    }
    
    try {
        // Update last login
        $update_login = "UPDATE customers SET last_login = NOW() WHERE id = :id";
        $update_stmt = $db->prepare($update_login);
        $update_stmt->bindParam(':id', $customer['id']);
        $update_stmt->execute();
        
        // Generate session token (in a real app, use JWT or proper session management)
        $session_token = bin2hex(random_bytes(32));
        
        $response = [
            'customer_id' => $customer['id'],
            'first_name' => $customer['first_name'],
            'last_name' => $customer['last_name'],
            'email' => $customer['email'],
            'email_verified' => (bool)$customer['email_verified'],
            'session_token' => $session_token
        ];
        
        successResponse($response, "Login successful");
        
    } catch (Exception $e) {
        error_log("Login customer error: " . $e->getMessage());
        errorResponse("Login failed", 500);
    }
}

/**
 * Create customer (admin function)
 */
function createCustomer($db) {
    $data = getInputData();
    $required_fields = ['first_name', 'last_name', 'email'];
    validateRequired($data, $required_fields);
    
    $data = sanitizeInput($data);
    
    try {
        $customer_id = generateUUID();
        $password_hash = isset($data['password']) ? password_hash($data['password'], PASSWORD_DEFAULT) : null;
        
        $query = "INSERT INTO customers (
                    id, first_name, last_name, email, phone, password_hash, 
                    date_of_birth, email_verified
                  ) VALUES (
                    :id, :first_name, :last_name, :email, :phone, :password_hash,
                    :date_of_birth, :email_verified
                  )";
        
        $stmt = $db->prepare($query);
        $stmt->execute([
            ':id' => $customer_id,
            ':first_name' => $data['first_name'],
            ':last_name' => $data['last_name'],
            ':email' => $data['email'],
            ':phone' => $data['phone'] ?? null,
            ':password_hash' => $password_hash,
            ':date_of_birth' => $data['date_of_birth'] ?? null,
            ':email_verified' => $data['email_verified'] ?? false
        ]);
        
        successResponse(['customer_id' => $customer_id], "Customer created successfully");
        
    } catch (Exception $e) {
        if ($e->getCode() == 23000) { // Duplicate entry
            errorResponse("Email already exists", 409);
        }
        error_log("Create customer error: " . $e->getMessage());
        errorResponse("Failed to create customer", 500);
    }
}

/**
 * Update customer
 */
function updateCustomer($db, $customer_id) {
    $data = getInputData();
    $data = sanitizeInput($data);
    
    try {
        // Check if customer exists
        $check_query = "SELECT id FROM customers WHERE id = :id AND is_active = 1";
        $check_stmt = $db->prepare($check_query);
        $check_stmt->bindParam(':id', $customer_id);
        $check_stmt->execute();
        
        if (!$check_stmt->fetch()) {
            errorResponse("Customer not found", 404);
        }
        
        // Build update query dynamically
        $update_fields = [];
        $params = [':id' => $customer_id];
        
        $allowed_fields = [
            'first_name', 'last_name', 'email', 'phone', 'date_of_birth'
        ];
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                $update_fields[] = "$field = :$field";
                $params[":$field"] = $data[$field];
            }
        }
        
        // Handle password update separately
        if (isset($data['password']) && !empty($data['password'])) {
            $update_fields[] = "password_hash = :password_hash";
            $params[':password_hash'] = password_hash($data['password'], PASSWORD_DEFAULT);
        }
        
        if (empty($update_fields)) {
            errorResponse("No valid fields to update", 400);
        }
        
        $query = "UPDATE customers SET " . implode(', ', $update_fields) . " WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->execute($params);
        
        successResponse([], "Customer updated successfully");
        
    } catch (Exception $e) {
        if ($e->getCode() == 23000) { // Duplicate entry
            errorResponse("Email already exists", 409);
        }
        error_log("Update customer error: " . $e->getMessage());
        errorResponse("Failed to update customer", 500);
    }
}

/**
 * Delete customer (soft delete)
 */
function deleteCustomer($db, $customer_id) {
    try {
        $query = "UPDATE customers SET is_active = 0 WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $customer_id);
        
        if ($stmt->execute() && $stmt->rowCount() > 0) {
            successResponse([], "Customer deleted successfully");
        } else {
            errorResponse("Customer not found", 404);
        }
        
    } catch (Exception $e) {
        error_log("Delete customer error: " . $e->getMessage());
        errorResponse("Failed to delete customer", 500);
    }
}

/**
 * Verify email
 */
function verifyEmail($db) {
    $data = getInputData();
    
    if (!isset($data['email']) || !isset($data['token'])) {
        errorResponse("Email and verification token required", 400);
    }
    
    // In a real application, you would validate the token against stored tokens
    try {
        $query = "UPDATE customers 
                  SET email_verified = 1, email_verified_at = NOW() 
                  WHERE email = :email";
        
        $stmt = $db->prepare($query);
        $stmt->bindParam(':email', $data['email']);
        
        if ($stmt->execute() && $stmt->rowCount() > 0) {
            successResponse([], "Email verified successfully");
        } else {
            errorResponse("Invalid verification token", 400);
        }
        
    } catch (Exception $e) {
        error_log("Verify email error: " . $e->getMessage());
        errorResponse("Email verification failed", 500);
    }
}

/**
 * Forgot password
 */
function forgotPassword($db) {
    $data = getInputData();
    
    if (!isset($data['email']) || empty($data['email'])) {
        errorResponse("Email is required", 400);
    }
    
    $email = sanitizeInput($data['email']);
    
    // Check if email exists
    $query = "SELECT id FROM customers WHERE email = :email AND is_active = 1";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    
    if ($stmt->fetch()) {
        // Generate reset token (in a real app, store this and send email)
        $reset_token = bin2hex(random_bytes(32));
        
        successResponse([
            'reset_token' => $reset_token,
            'message' => 'Password reset instructions sent to your email'
        ], "Reset token generated");
    } else {
        // Don't reveal if email exists or not for security
        successResponse([
            'message' => 'If the email exists, reset instructions have been sent'
        ], "Reset request processed");
    }
}

/**
 * Reset password
 */
function resetPassword($db) {
    $data = getInputData();
    $required_fields = ['email', 'token', 'new_password'];
    validateRequired($data, $required_fields);
    
    $data = sanitizeInput($data);
    
    // In a real application, validate the reset token
    try {
        $password_hash = password_hash($data['new_password'], PASSWORD_DEFAULT);
        
        $query = "UPDATE customers 
                  SET password_hash = :password_hash 
                  WHERE email = :email AND is_active = 1";
        
        $stmt = $db->prepare($query);
        $stmt->bindParam(':password_hash', $password_hash);
        $stmt->bindParam(':email', $data['email']);
        
        if ($stmt->execute() && $stmt->rowCount() > 0) {
            successResponse([], "Password reset successfully");
        } else {
            errorResponse("Invalid reset token or email", 400);
        }
        
    } catch (Exception $e) {
        error_log("Reset password error: " . $e->getMessage());
        errorResponse("Password reset failed", 500);
    }
}
?>

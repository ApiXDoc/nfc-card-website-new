<?php
/**
 * Categories & General API Endpoints
 * Handles categories, site settings, and general utilities
 */

require_once '../config/database.php';

setCorsHeaders();

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$request_uri = $_SERVER['REQUEST_URI'];
$path_parts = explode('/', trim(parse_url($request_uri, PHP_URL_PATH), '/'));

try {
    // Determine endpoint type
    if (isset($path_parts[2])) {
        switch ($path_parts[2]) {
            case 'categories':
                handleCategories($db, $method, $path_parts);
                break;
            case 'settings':
                handleSettings($db, $method, $path_parts);
                break;
            case 'shipping':
                handleShipping($db, $method, $path_parts);
                break;
            case 'coupons':
                handleCoupons($db, $method, $path_parts);
                break;
            case 'reviews':
                handleReviews($db, $method, $path_parts);
                break;
            case 'newsletter':
                handleNewsletter($db, $method, $path_parts);
                break;
            case 'stats':
                handleStats($db, $method, $path_parts);
                break;
            default:
                errorResponse("Invalid endpoint", 404);
        }
    } else {
        errorResponse("Endpoint not specified", 400);
    }
} catch (Exception $e) {
    error_log("General API Error: " . $e->getMessage());
    errorResponse("Internal server error", 500);
}

/**
 * Handle Categories endpoints
 */
function handleCategories($db, $method, $path_parts) {
    switch ($method) {
        case 'GET':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                getCategoryById($db, $path_parts[3]);
            } else {
                getAllCategories($db);
            }
            break;
            
        case 'POST':
            createCategory($db);
            break;
            
        case 'PUT':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                updateCategory($db, $path_parts[3]);
            } else {
                errorResponse("Category ID required for update", 400);
            }
            break;
            
        case 'DELETE':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                deleteCategory($db, $path_parts[3]);
            } else {
                errorResponse("Category ID required for deletion", 400);
            }
            break;
            
        default:
            errorResponse("Method not allowed", 405);
            break;
    }
}

/**
 * Handle Settings endpoints
 */
function handleSettings($db, $method, $path_parts) {
    switch ($method) {
        case 'GET':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                getSettingByKey($db, $path_parts[3]);
            } else {
                getAllSettings($db);
            }
            break;
            
        case 'POST':
        case 'PUT':
            updateSetting($db);
            break;
            
        default:
            errorResponse("Method not allowed", 405);
            break;
    }
}

/**
 * Handle Shipping endpoints
 */
function handleShipping($db, $method, $path_parts) {
    switch ($method) {
        case 'GET':
            getAllShippingMethods($db);
            break;
            
        case 'POST':
            createShippingMethod($db);
            break;
            
        case 'PUT':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                updateShippingMethod($db, $path_parts[3]);
            } else {
                errorResponse("Shipping method ID required for update", 400);
            }
            break;
            
        default:
            errorResponse("Method not allowed", 405);
            break;
    }
}

/**
 * Handle Coupons endpoints
 */
function handleCoupons($db, $method, $path_parts) {
    switch ($method) {
        case 'GET':
            getAllCoupons($db);
            break;
            
        case 'POST':
            if (isset($path_parts[3]) && $path_parts[3] === 'validate') {
                validateCoupon($db);
            } else {
                createCoupon($db);
            }
            break;
            
        case 'PUT':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                updateCoupon($db, $path_parts[3]);
            } else {
                errorResponse("Coupon ID required for update", 400);
            }
            break;
            
        default:
            errorResponse("Method not allowed", 405);
            break;
    }
}

/**
 * Handle Reviews endpoints
 */
function handleReviews($db, $method, $path_parts) {
    switch ($method) {
        case 'GET':
            getAllReviews($db);
            break;
            
        case 'POST':
            createReview($db);
            break;
            
        case 'PUT':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                updateReview($db, $path_parts[3]);
            } else {
                errorResponse("Review ID required for update", 400);
            }
            break;
            
        default:
            errorResponse("Method not allowed", 405);
            break;
    }
}

/**
 * Handle Newsletter endpoints
 */
function handleNewsletter($db, $method, $path_parts) {
    switch ($method) {
        case 'POST':
            if (isset($path_parts[3])) {
                if ($path_parts[3] === 'subscribe') {
                    subscribeNewsletter($db);
                } elseif ($path_parts[3] === 'unsubscribe') {
                    unsubscribeNewsletter($db);
                }
            }
            break;
            
        default:
            errorResponse("Method not allowed", 405);
            break;
    }
}

/**
 * Handle Stats endpoints
 */
function handleStats($db, $method, $path_parts) {
    if ($method === 'GET') {
        if (isset($path_parts[3])) {
            switch ($path_parts[3]) {
                case 'dashboard':
                    getDashboardStats($db);
                    break;
                case 'sales':
                    getSalesStats($db);
                    break;
                case 'products':
                    getProductStats($db);
                    break;
                case 'customers':
                    getCustomerStats($db);
                    break;
                default:
                    errorResponse("Invalid stats endpoint", 404);
            }
        } else {
            getDashboardStats($db);
        }
    } else {
        errorResponse("Method not allowed", 405);
    }
}

// ============================================================================
// CATEGORIES FUNCTIONS
// ============================================================================

function getAllCategories($db) {
    $query = "SELECT c.*,
                     COUNT(p.id) as product_count
              FROM categories c
              LEFT JOIN products p ON c.id = p.category_id AND p.is_active = 1
              WHERE c.is_active = 1
              GROUP BY c.id
              ORDER BY c.sort_order ASC, c.name ASC";
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    $categories = $stmt->fetchAll();
    
    foreach ($categories as &$category) {
        $category['product_count'] = intval($category['product_count']);
        $category['sort_order'] = intval($category['sort_order']);
    }
    
    successResponse($categories, "Categories retrieved successfully");
}

function getCategoryById($db, $category_id) {
    $query = "SELECT c.*,
                     COUNT(p.id) as product_count
              FROM categories c
              LEFT JOIN products p ON c.id = p.category_id AND p.is_active = 1
              WHERE c.id = :id AND c.is_active = 1
              GROUP BY c.id";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $category_id);
    $stmt->execute();
    
    $category = $stmt->fetch();
    
    if (!$category) {
        errorResponse("Category not found", 404);
    }
    
    $category['product_count'] = intval($category['product_count']);
    
    successResponse($category, "Category retrieved successfully");
}

function createCategory($db) {
    $data = getInputData();
    $required_fields = ['name', 'slug'];
    validateRequired($data, $required_fields);
    
    $data = sanitizeInput($data);
    
    try {
        $query = "INSERT INTO categories (name, description, slug, sort_order, is_active) 
                  VALUES (:name, :description, :slug, :sort_order, :is_active)";
        
        $stmt = $db->prepare($query);
        $stmt->execute([
            ':name' => $data['name'],
            ':description' => $data['description'] ?? null,
            ':slug' => $data['slug'],
            ':sort_order' => $data['sort_order'] ?? 0,
            ':is_active' => $data['is_active'] ?? true
        ]);
        
        $category_id = $db->lastInsertId();
        
        successResponse(['category_id' => $category_id], "Category created successfully");
        
    } catch (Exception $e) {
        if ($e->getCode() == 23000) {
            errorResponse("Category name or slug already exists", 409);
        }
        error_log("Create category error: " . $e->getMessage());
        errorResponse("Failed to create category", 500);
    }
}

// ============================================================================
// SETTINGS FUNCTIONS
// ============================================================================

function getAllSettings($db) {
    $public_only = isset($_GET['public']) && $_GET['public'] === 'true';
    
    $where_clause = $public_only ? "WHERE is_public = 1" : "";
    
    $query = "SELECT setting_key, setting_value, setting_type, description, is_public 
              FROM site_settings {$where_clause}
              ORDER BY setting_key";
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    $settings = $stmt->fetchAll();
    
    // Convert to key-value format
    $formatted_settings = [];
    foreach ($settings as $setting) {
        $value = $setting['setting_value'];
        
        // Type conversion
        switch ($setting['setting_type']) {
            case 'number':
                $value = is_numeric($value) ? (float)$value : 0;
                break;
            case 'boolean':
                $value = (bool)$value;
                break;
            case 'json':
                $value = json_decode($value, true);
                break;
        }
        
        $formatted_settings[$setting['setting_key']] = $value;
    }
    
    successResponse($formatted_settings, "Settings retrieved successfully");
}

function getSettingByKey($db, $key) {
    $query = "SELECT * FROM site_settings WHERE setting_key = :key";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':key', $key);
    $stmt->execute();
    
    $setting = $stmt->fetch();
    
    if (!$setting) {
        errorResponse("Setting not found", 404);
    }
    
    successResponse($setting, "Setting retrieved successfully");
}

function updateSetting($db) {
    $data = getInputData();
    $required_fields = ['setting_key', 'setting_value'];
    validateRequired($data, $required_fields);
    
    $data = sanitizeInput($data);
    
    try {
        $query = "INSERT INTO site_settings (setting_key, setting_value, setting_type, description, is_public) 
                  VALUES (:key, :value, :type, :description, :is_public)
                  ON DUPLICATE KEY UPDATE 
                  setting_value = VALUES(setting_value),
                  setting_type = VALUES(setting_type),
                  description = VALUES(description),
                  is_public = VALUES(is_public),
                  updated_at = NOW()";
        
        $stmt = $db->prepare($query);
        $stmt->execute([
            ':key' => $data['setting_key'],
            ':value' => $data['setting_value'],
            ':type' => $data['setting_type'] ?? 'string',
            ':description' => $data['description'] ?? null,
            ':is_public' => $data['is_public'] ?? false
        ]);
        
        successResponse([], "Setting updated successfully");
        
    } catch (Exception $e) {
        error_log("Update setting error: " . $e->getMessage());
        errorResponse("Failed to update setting", 500);
    }
}

// ============================================================================
// SHIPPING FUNCTIONS
// ============================================================================

function getAllShippingMethods($db) {
    $query = "SELECT * FROM shipping_methods WHERE is_active = 1 ORDER BY sort_order ASC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $methods = $stmt->fetchAll();
    
    foreach ($methods as &$method) {
        $method['price'] = floatval($method['price']);
        $method['estimated_days_min'] = intval($method['estimated_days_min']);
        $method['estimated_days_max'] = intval($method['estimated_days_max']);
        $method['sort_order'] = intval($method['sort_order']);
    }
    
    successResponse($methods, "Shipping methods retrieved successfully");
}

// ============================================================================
// NEWSLETTER FUNCTIONS
// ============================================================================

function subscribeNewsletter($db) {
    $data = getInputData();
    $required_fields = ['email'];
    validateRequired($data, $required_fields);
    
    $data = sanitizeInput($data);
    
    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        errorResponse("Invalid email format", 400);
    }
    
    try {
        $query = "INSERT INTO newsletter_subscriptions (email, name, confirmed) 
                  VALUES (:email, :name, :confirmed)
                  ON DUPLICATE KEY UPDATE 
                  name = VALUES(name),
                  is_active = 1,
                  unsubscribed_at = NULL";
        
        $stmt = $db->prepare($query);
        $stmt->execute([
            ':email' => $data['email'],
            ':name' => $data['name'] ?? null,
            ':confirmed' => true // In a real app, send confirmation email
        ]);
        
        successResponse([], "Newsletter subscription successful");
        
    } catch (Exception $e) {
        error_log("Newsletter subscribe error: " . $e->getMessage());
        errorResponse("Failed to subscribe", 500);
    }
}

function unsubscribeNewsletter($db) {
    $data = getInputData();
    $required_fields = ['email'];
    validateRequired($data, $required_fields);
    
    $email = sanitizeInput($data['email']);
    
    try {
        $query = "UPDATE newsletter_subscriptions 
                  SET is_active = 0, unsubscribed_at = NOW() 
                  WHERE email = :email";
        
        $stmt = $db->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        
        successResponse([], "Unsubscribed successfully");
        
    } catch (Exception $e) {
        error_log("Newsletter unsubscribe error: " . $e->getMessage());
        errorResponse("Failed to unsubscribe", 500);
    }
}

// ============================================================================
// STATS FUNCTIONS
// ============================================================================

function getDashboardStats($db) {
    try {
        // Call stored procedures
        $product_stats = $db->query("CALL GetProductStats()")->fetchAll();
        $customer_stats = $db->query("CALL GetCustomerStats()")->fetch();
        $sales_stats = $db->query("CALL GetSalesStats(30)")->fetchAll();
        
        // Additional queries
        $recent_orders = $db->query("
            SELECT COUNT(*) as count FROM orders 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        ")->fetch()['count'];
        
        $pending_messages = $db->query("
            SELECT COUNT(*) as count FROM contact_messages 
            WHERE status = 'new'
        ")->fetch()['count'];
        
        $low_stock = $db->query("
            SELECT COUNT(*) as count FROM products 
            WHERE stock_quantity <= 10 AND is_active = 1
        ")->fetch()['count'];
        
        $total_revenue = 0;
        foreach ($sales_stats as $stat) {
            $total_revenue += floatval($stat['total_revenue']);
        }
        
        $stats = [
            'products' => $product_stats,
            'customers' => $customer_stats,
            'sales_last_30_days' => $sales_stats,
            'alerts' => [
                'new_orders_today' => intval($recent_orders),
                'pending_messages' => intval($pending_messages),
                'low_stock_products' => intval($low_stock)
            ],
            'summary' => [
                'total_revenue_30_days' => $total_revenue,
                'average_order_value' => count($sales_stats) > 0 ? $total_revenue / count($sales_stats) : 0
            ]
        ];
        
        successResponse($stats, "Dashboard stats retrieved successfully");
        
    } catch (Exception $e) {
        error_log("Dashboard stats error: " . $e->getMessage());
        errorResponse("Failed to retrieve stats", 500);
    }
}

function createReview($db) {
    $data = getInputData();
    $required_fields = ['product_id', 'customer_name', 'customer_email', 'rating', 'review_text'];
    validateRequired($data, $required_fields);
    
    $data = sanitizeInput($data);
    
    // Validate rating
    if ($data['rating'] < 1 || $data['rating'] > 5) {
        errorResponse("Rating must be between 1 and 5", 400);
    }
    
    // Validate email
    if (!filter_var($data['customer_email'], FILTER_VALIDATE_EMAIL)) {
        errorResponse("Invalid email format", 400);
    }
    
    try {
        $query = "INSERT INTO product_reviews (
                    product_id, customer_id, customer_name, customer_email, 
                    rating, title, review_text, is_verified
                  ) VALUES (
                    :product_id, :customer_id, :customer_name, :customer_email,
                    :rating, :title, :review_text, :is_verified
                  )";
        
        $stmt = $db->prepare($query);
        $stmt->execute([
            ':product_id' => $data['product_id'],
            ':customer_id' => $data['customer_id'] ?? null,
            ':customer_name' => $data['customer_name'],
            ':customer_email' => $data['customer_email'],
            ':rating' => $data['rating'],
            ':title' => $data['title'] ?? null,
            ':review_text' => $data['review_text'],
            ':is_verified' => isset($data['customer_id']) ? true : false
        ]);
        
        $review_id = $db->lastInsertId();
        
        successResponse([
            'review_id' => $review_id,
            'message' => 'Review submitted successfully. It will be published after moderation.'
        ], "Review created successfully");
        
    } catch (Exception $e) {
        error_log("Create review error: " . $e->getMessage());
        errorResponse("Failed to create review", 500);
    }
}

function getAllReviews($db) {
    $pagination = getPaginationParams();
    $where_conditions = [];
    $params = [];
    
    // Product filter
    if (isset($_GET['product_id']) && !empty($_GET['product_id'])) {
        $where_conditions[] = "pr.product_id = :product_id";
        $params[':product_id'] = $_GET['product_id'];
    }
    
    // Approval status filter
    if (isset($_GET['approved'])) {
        $where_conditions[] = "pr.is_approved = :approved";
        $params[':approved'] = $_GET['approved'] === 'true' ? 1 : 0;
    }
    
    // Rating filter
    if (isset($_GET['rating']) && is_numeric($_GET['rating'])) {
        $where_conditions[] = "pr.rating = :rating";
        $params[':rating'] = $_GET['rating'];
    }
    
    $where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";
    
    // Count total records
    $count_query = "SELECT COUNT(*) as total FROM product_reviews pr {$where_clause}";
    $count_stmt = $db->prepare($count_query);
    $count_stmt->execute($params);
    $total = $count_stmt->fetch()['total'];
    
    // Get reviews with pagination
    $query = "SELECT pr.*, p.name as product_name, p.slug as product_slug
              FROM product_reviews pr
              LEFT JOIN products p ON pr.product_id = p.id
              {$where_clause}
              ORDER BY pr.created_at DESC
              LIMIT :limit OFFSET :offset";
    
    $stmt = $db->prepare($query);
    
    // Bind pagination parameters
    $stmt->bindValue(':limit', $pagination['limit'], PDO::PARAM_INT);
    $stmt->bindValue(':offset', $pagination['offset'], PDO::PARAM_INT);
    
    // Bind other parameters
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    $stmt->execute();
    $reviews = $stmt->fetchAll();
    
    // Process data
    foreach ($reviews as &$review) {
        $review['rating'] = intval($review['rating']);
        $review['is_verified'] = (bool)$review['is_verified'];
        $review['is_approved'] = (bool)$review['is_approved'];
        $review['helpful_count'] = intval($review['helpful_count']);
    }
    
    $response = buildPaginationResponse($reviews, $total, $pagination['page'], $pagination['limit']);
    successResponse($response, "Reviews retrieved successfully");
}

function validateCoupon($db) {
    $data = getInputData();
    $required_fields = ['code', 'order_total'];
    validateRequired($data, $required_fields);
    
    $code = sanitizeInput($data['code']);
    $order_total = floatval($data['order_total']);
    
    $query = "SELECT * FROM coupons 
              WHERE code = :code 
              AND is_active = 1 
              AND (usage_limit IS NULL OR usage_count < usage_limit)
              AND (valid_until IS NULL OR valid_until >= NOW())
              AND valid_from <= NOW()";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':code', $code);
    $stmt->execute();
    
    $coupon = $stmt->fetch();
    
    if (!$coupon) {
        errorResponse("Invalid or expired coupon code", 400);
    }
    
    // Check minimum order amount
    if ($order_total < $coupon['minimum_order_amount']) {
        errorResponse(
            "Minimum order amount of $" . number_format($coupon['minimum_order_amount'], 2) . " required",
            400
        );
    }
    
    // Calculate discount
    $discount_amount = 0;
    switch ($coupon['type']) {
        case 'percentage':
            $discount_amount = ($order_total * $coupon['value']) / 100;
            break;
        case 'fixed_amount':
            $discount_amount = min($coupon['value'], $order_total);
            break;
        case 'free_shipping':
            $discount_amount = 0; // Handled separately in shipping calculation
            break;
    }
    
    $response = [
        'valid' => true,
        'coupon' => [
            'id' => $coupon['id'],
            'code' => $coupon['code'],
            'name' => $coupon['name'],
            'type' => $coupon['type'],
            'value' => floatval($coupon['value']),
            'discount_amount' => $discount_amount
        ]
    ];
    
    successResponse($response, "Coupon is valid");
}
?>

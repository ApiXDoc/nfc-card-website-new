<?php
/**
 * Orders API Endpoints
 * Handles all order-related operations
 */

require_once '../config/database.php';

setCorsHeaders();

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$request_uri = $_SERVER['REQUEST_URI'];
$path_parts = explode('/', trim(parse_url($request_uri, PHP_URL_PATH), '/'));

try {
    switch ($method) {
        case 'GET':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                // Get single order by ID or order number
                getOrderById($db, $path_parts[3]);
            } else {
                // Get all orders with filters and pagination
                getAllOrders($db);
            }
            break;
            
        case 'POST':
            if (isset($path_parts[3]) && $path_parts[3] === 'track') {
                // Track order by order number
                trackOrder($db);
            } else {
                // Create new order
                createOrder($db);
            }
            break;
            
        case 'PUT':
            if (isset($path_parts[3]) && !empty($path_parts[3])) {
                updateOrder($db, $path_parts[3]);
            } else {
                errorResponse("Order ID required for update", 400);
            }
            break;
            
        default:
            errorResponse("Method not allowed", 405);
            break;
    }
} catch (Exception $e) {
    error_log("Orders API Error: " . $e->getMessage());
    errorResponse("Internal server error", 500);
}

/**
 * Get all orders with filters and pagination
 */
function getAllOrders($db) {
    $pagination = getPaginationParams();
    $where_conditions = [];
    $params = [];
    
    // Base query
    $base_query = "FROM order_summary_view o WHERE 1=1";
    
    // Customer filter
    if (isset($_GET['customer_id']) && !empty($_GET['customer_id'])) {
        $where_conditions[] = "o.customer_id = :customer_id";
        $params[':customer_id'] = $_GET['customer_id'];
    }
    
    // Status filter
    if (isset($_GET['status']) && !empty($_GET['status'])) {
        $where_conditions[] = "o.status = :status";
        $params[':status'] = $_GET['status'];
    }
    
    // Payment status filter
    if (isset($_GET['payment_status']) && !empty($_GET['payment_status'])) {
        $where_conditions[] = "o.payment_status = :payment_status";
        $params[':payment_status'] = $_GET['payment_status'];
    }
    
    // Date range filter
    if (isset($_GET['start_date']) && !empty($_GET['start_date'])) {
        $where_conditions[] = "DATE(o.created_at) >= :start_date";
        $params[':start_date'] = $_GET['start_date'];
    }
    
    if (isset($_GET['end_date']) && !empty($_GET['end_date'])) {
        $where_conditions[] = "DATE(o.created_at) <= :end_date";
        $params[':end_date'] = $_GET['end_date'];
    }
    
    // Email search
    if (isset($_GET['email']) && !empty($_GET['email'])) {
        $where_conditions[] = "o.customer_email LIKE :email";
        $params[':email'] = '%' . $_GET['email'] . '%';
    }
    
    // Add WHERE conditions
    if (!empty($where_conditions)) {
        $base_query .= " AND " . implode(" AND ", $where_conditions);
    }
    
    // Count total records
    $count_query = "SELECT COUNT(*) as total " . $base_query;
    $count_stmt = $db->prepare($count_query);
    $count_stmt->execute($params);
    $total = $count_stmt->fetch()['total'];
    
    // Get orders with pagination
    $sort_by = isset($_GET['sort']) ? $_GET['sort'] : 'created_at';
    $sort_order = isset($_GET['order']) && strtoupper($_GET['order']) === 'ASC' ? 'ASC' : 'DESC';
    
    // Validate sort field
    $allowed_sort_fields = ['order_number', 'customer_email', 'status', 'total_amount', 'created_at'];
    if (!in_array($sort_by, $allowed_sort_fields)) {
        $sort_by = 'created_at';
    }
    
    $query = "SELECT o.* " . $base_query . "
              ORDER BY o.{$sort_by} {$sort_order}
              LIMIT :limit OFFSET :offset";
    
    $stmt = $db->prepare($query);
    
    // Bind pagination parameters
    $stmt->bindValue(':limit', $pagination['limit'], PDO::PARAM_INT);
    $stmt->bindValue(':offset', $pagination['offset'], PDO::PARAM_INT);
    
    // Bind other parameters
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    $stmt->execute();
    $orders = $stmt->fetchAll();
    
    // Process data
    foreach ($orders as &$order) {
        $order['subtotal'] = floatval($order['subtotal']);
        $order['shipping_cost'] = floatval($order['shipping_cost']);
        $order['tax_amount'] = floatval($order['tax_amount']);
        $order['discount_amount'] = floatval($order['discount_amount']);
        $order['total_amount'] = floatval($order['total_amount']);
        $order['item_count'] = intval($order['item_count']);
        $order['total_quantity'] = intval($order['total_quantity']);
    }
    
    $response = buildPaginationResponse($orders, $total, $pagination['page'], $pagination['limit']);
    successResponse($response, "Orders retrieved successfully");
}

/**
 * Get single order by ID or order number
 */
function getOrderById($db, $identifier) {
    // Check if identifier is order number or ID
    $field = (strpos($identifier, 'NFC') === 0) ? 'order_number' : 'id';
    
    $query = "SELECT o.*,
                     osi.first_name as shipping_first_name,
                     osi.last_name as shipping_last_name,
                     osi.company as shipping_company,
                     osi.street_address as shipping_street,
                     osi.address_line_2 as shipping_address_2,
                     osi.city as shipping_city,
                     osi.state as shipping_state,
                     osi.postal_code as shipping_postal_code,
                     osi.country as shipping_country,
                     osi.tracking_number,
                     osi.carrier,
                     osi.tracking_url,
                     sm.name as shipping_method_name,
                     sm.description as shipping_method_description
              FROM orders o
              LEFT JOIN order_shipping_info osi ON o.id = osi.order_id
              LEFT JOIN shipping_methods sm ON o.shipping_method_id = sm.id
              WHERE o.{$field} = :identifier";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':identifier', $identifier);
    $stmt->execute();
    
    $order = $stmt->fetch();
    
    if (!$order) {
        errorResponse("Order not found", 404);
    }
    
    // Get order items
    $items_query = "SELECT oi.*, p.slug as product_slug, p.image as product_image
                    FROM order_items oi
                    LEFT JOIN products p ON oi.product_id = p.id
                    WHERE oi.order_id = :order_id
                    ORDER BY oi.id";
    
    $items_stmt = $db->prepare($items_query);
    $items_stmt->bindParam(':order_id', $order['id']);
    $items_stmt->execute();
    $order['items'] = $items_stmt->fetchAll();
    
    // Get order tracking history
    $tracking_query = "SELECT * FROM order_tracking 
                       WHERE order_id = :order_id 
                       ORDER BY created_at ASC";
    
    $tracking_stmt = $db->prepare($tracking_query);
    $tracking_stmt->bindParam(':order_id', $order['id']);
    $tracking_stmt->execute();
    $order['tracking_history'] = $tracking_stmt->fetchAll();
    
    // Get billing info
    $billing_query = "SELECT * FROM order_billing_info WHERE order_id = :order_id";
    $billing_stmt = $db->prepare($billing_query);
    $billing_stmt->bindParam(':order_id', $order['id']);
    $billing_stmt->execute();
    $order['billing_info'] = $billing_stmt->fetch();
    
    // Process data
    $order['subtotal'] = floatval($order['subtotal']);
    $order['shipping_cost'] = floatval($order['shipping_cost']);
    $order['tax_amount'] = floatval($order['tax_amount']);
    $order['discount_amount'] = floatval($order['discount_amount']);
    $order['total_amount'] = floatval($order['total_amount']);
    
    foreach ($order['items'] as &$item) {
        $item['quantity'] = intval($item['quantity']);
        $item['unit_price'] = floatval($item['unit_price']);
        $item['total_price'] = floatval($item['total_price']);
    }
    
    successResponse($order, "Order retrieved successfully");
}

/**
 * Create new order
 */
function createOrder($db) {
    $data = getInputData();
    $required_fields = ['customer_email', 'items', 'shipping_info', 'billing_info'];
    validateRequired($data, $required_fields);
    
    $data = sanitizeInput($data);
    
    try {
        $db->beginTransaction();
        
        $order_id = generateUUID();
        $order_number = generateOrderNumber($db);
        
        // Calculate totals
        $subtotal = 0;
        foreach ($data['items'] as $item) {
            $subtotal += $item['quantity'] * $item['unit_price'];
        }
        
        $shipping_cost = $data['shipping_cost'] ?? 0;
        $tax_amount = $data['tax_amount'] ?? 0;
        $discount_amount = $data['discount_amount'] ?? 0;
        $total_amount = $subtotal + $shipping_cost + $tax_amount - $discount_amount;
        
        // Create order
        $order_query = "INSERT INTO orders (
                          id, order_number, customer_id, customer_email, customer_phone,
                          status, subtotal, shipping_cost, tax_amount, discount_amount,
                          total_amount, payment_method, shipping_method_id, notes
                        ) VALUES (
                          :id, :order_number, :customer_id, :customer_email, :customer_phone,
                          :status, :subtotal, :shipping_cost, :tax_amount, :discount_amount,
                          :total_amount, :payment_method, :shipping_method_id, :notes
                        )";
        
        $order_stmt = $db->prepare($order_query);
        $order_stmt->execute([
            ':id' => $order_id,
            ':order_number' => $order_number,
            ':customer_id' => $data['customer_id'] ?? null,
            ':customer_email' => $data['customer_email'],
            ':customer_phone' => $data['customer_phone'] ?? null,
            ':status' => 'pending',
            ':subtotal' => $subtotal,
            ':shipping_cost' => $shipping_cost,
            ':tax_amount' => $tax_amount,
            ':discount_amount' => $discount_amount,
            ':total_amount' => $total_amount,
            ':payment_method' => $data['payment_method'] ?? null,
            ':shipping_method_id' => $data['shipping_method_id'] ?? null,
            ':notes' => $data['notes'] ?? null
        ]);
        
        // Add order items
        $item_query = "INSERT INTO order_items (
                         order_id, product_id, product_name, product_sku,
                         quantity, unit_price, total_price
                       ) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        $item_stmt = $db->prepare($item_query);
        
        foreach ($data['items'] as $item) {
            $item_total = $item['quantity'] * $item['unit_price'];
            $item_stmt->execute([
                $order_id,
                $item['product_id'],
                $item['product_name'],
                $item['product_sku'] ?? null,
                $item['quantity'],
                $item['unit_price'],
                $item_total
            ]);
        }
        
        // Add shipping info
        $shipping_query = "INSERT INTO order_shipping_info (
                             order_id, first_name, last_name, company, street_address,
                             address_line_2, city, state, postal_code, country
                           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $shipping_stmt = $db->prepare($shipping_query);
        $shipping_info = $data['shipping_info'];
        $shipping_stmt->execute([
            $order_id,
            $shipping_info['first_name'],
            $shipping_info['last_name'],
            $shipping_info['company'] ?? null,
            $shipping_info['street_address'],
            $shipping_info['address_line_2'] ?? null,
            $shipping_info['city'],
            $shipping_info['state'],
            $shipping_info['postal_code'],
            $shipping_info['country']
        ]);
        
        // Add billing info
        $billing_query = "INSERT INTO order_billing_info (
                            order_id, first_name, last_name, company, street_address,
                            address_line_2, city, state, postal_code, country
                          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $billing_stmt = $db->prepare($billing_query);
        $billing_info = $data['billing_info'];
        $billing_stmt->execute([
            $order_id,
            $billing_info['first_name'],
            $billing_info['last_name'],
            $billing_info['company'] ?? null,
            $billing_info['street_address'],
            $billing_info['address_line_2'] ?? null,
            $billing_info['city'],
            $billing_info['state'],
            $billing_info['postal_code'],
            $billing_info['country']
        ]);
        
        // Add initial tracking entry
        $tracking_query = "INSERT INTO order_tracking (order_id, status, message, created_by) 
                           VALUES (?, 'pending', 'Order received and payment pending', 'system')";
        $db->prepare($tracking_query)->execute([$order_id]);
        
        $db->commit();
        
        successResponse([
            'order_id' => $order_id,
            'order_number' => $order_number,
            'total_amount' => $total_amount
        ], "Order created successfully");
        
    } catch (Exception $e) {
        $db->rollBack();
        error_log("Create order error: " . $e->getMessage());
        errorResponse("Failed to create order", 500);
    }
}

/**
 * Update order status
 */
function updateOrder($db, $order_id) {
    $data = getInputData();
    $data = sanitizeInput($data);
    
    try {
        $db->beginTransaction();
        
        // Check if order exists
        $check_query = "SELECT id, status FROM orders WHERE id = :id OR order_number = :id";
        $check_stmt = $db->prepare($check_query);
        $check_stmt->bindParam(':id', $order_id);
        $check_stmt->execute();
        
        $order = $check_stmt->fetch();
        if (!$order) {
            errorResponse("Order not found", 404);
        }
        
        $actual_order_id = $order['id'];
        $old_status = $order['status'];
        
        // Update allowed fields
        $update_fields = [];
        $params = [':id' => $actual_order_id];
        
        $allowed_fields = [
            'status', 'payment_status', 'payment_transaction_id', 'notes'
        ];
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                $update_fields[] = "$field = :$field";
                $params[":$field"] = $data[$field];
            }
        }
        
        // Handle shipped_at and delivered_at timestamps
        if (isset($data['status'])) {
            if ($data['status'] === 'shipped' && $old_status !== 'shipped') {
                $update_fields[] = "shipped_at = NOW()";
            }
            if ($data['status'] === 'delivered' && $old_status !== 'delivered') {
                $update_fields[] = "delivered_at = NOW()";
            }
        }
        
        if (!empty($update_fields)) {
            $query = "UPDATE orders SET " . implode(', ', $update_fields) . " WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->execute($params);
        }
        
        // Add tracking entry if status changed
        if (isset($data['status']) && $data['status'] !== $old_status) {
            $tracking_message = $data['tracking_message'] ?? "Order status updated to {$data['status']}";
            $created_by = $data['updated_by'] ?? 'system';
            
            $tracking_query = "INSERT INTO order_tracking (order_id, status, message, created_by) 
                               VALUES (?, ?, ?, ?)";
            $db->prepare($tracking_query)->execute([
                $actual_order_id,
                $data['status'],
                $tracking_message,
                $created_by
            ]);
        }
        
        // Update tracking info if provided
        if (isset($data['tracking_number']) || isset($data['carrier'])) {
            $tracking_fields = [];
            $tracking_params = [':order_id' => $actual_order_id];
            
            if (isset($data['tracking_number'])) {
                $tracking_fields[] = "tracking_number = :tracking_number";
                $tracking_params[':tracking_number'] = $data['tracking_number'];
            }
            
            if (isset($data['carrier'])) {
                $tracking_fields[] = "carrier = :carrier";
                $tracking_params[':carrier'] = $data['carrier'];
            }
            
            if (isset($data['tracking_url'])) {
                $tracking_fields[] = "tracking_url = :tracking_url";
                $tracking_params[':tracking_url'] = $data['tracking_url'];
            }
            
            if (!empty($tracking_fields)) {
                $tracking_update = "UPDATE order_shipping_info SET " . implode(', ', $tracking_fields) . " WHERE order_id = :order_id";
                $db->prepare($tracking_update)->execute($tracking_params);
            }
        }
        
        $db->commit();
        
        successResponse([], "Order updated successfully");
        
    } catch (Exception $e) {
        $db->rollBack();
        error_log("Update order error: " . $e->getMessage());
        errorResponse("Failed to update order", 500);
    }
}

/**
 * Track order by order number
 */
function trackOrder($db) {
    $data = getInputData();
    
    if (!isset($data['order_number']) || empty($data['order_number'])) {
        errorResponse("Order number is required", 400);
    }
    
    $order_number = sanitizeInput($data['order_number']);
    
    $query = "SELECT o.id, o.order_number, o.status, o.created_at, o.shipped_at, o.delivered_at,
                     osi.tracking_number, osi.carrier, osi.tracking_url,
                     osi.first_name, osi.last_name, osi.city, osi.state
              FROM orders o
              LEFT JOIN order_shipping_info osi ON o.id = osi.order_id
              WHERE o.order_number = :order_number";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':order_number', $order_number);
    $stmt->execute();
    
    $order = $stmt->fetch();
    
    if (!$order) {
        errorResponse("Order not found", 404);
    }
    
    // Get tracking history
    $tracking_query = "SELECT status, message, created_at, created_by
                       FROM order_tracking 
                       WHERE order_id = :order_id 
                       ORDER BY created_at ASC";
    
    $tracking_stmt = $db->prepare($tracking_query);
    $tracking_stmt->bindParam(':order_id', $order['id']);
    $tracking_stmt->execute();
    $order['tracking_history'] = $tracking_stmt->fetchAll();
    
    // Remove sensitive order ID from response
    unset($order['id']);
    
    successResponse($order, "Order tracking retrieved successfully");
}

/**
 * Generate unique order number
 */
function generateOrderNumber($db) {
    $prefix = "NFC";
    $year = date('Y');
    
    // Get the last order number for this year
    $query = "SELECT order_number FROM orders 
              WHERE order_number LIKE :pattern 
              ORDER BY order_number DESC 
              LIMIT 1";
    
    $pattern = $prefix . $year . '%';
    $stmt = $db->prepare($query);
    $stmt->bindParam(':pattern', $pattern);
    $stmt->execute();
    
    $last_order = $stmt->fetch();
    
    if ($last_order) {
        $last_number = intval(substr($last_order['order_number'], -6));
        $new_number = $last_number + 1;
    } else {
        $new_number = 1;
    }
    
    return $prefix . $year . str_pad($new_number, 6, '0', STR_PAD_LEFT);
}
?>

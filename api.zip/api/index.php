<?php
/**
 * Main API Router
 * Routes requests to appropriate endpoint handlers
 */

require_once 'config/database.php';

// Set CORS headers
setCorsHeaders();

// Get request info
$method = $_SERVER['REQUEST_METHOD'];
$request_uri = $_SERVER['REQUEST_URI'];
$path = parse_url($request_uri, PHP_URL_PATH);
$path_parts = explode('/', trim($path, '/'));

// Remove 'api' from path if present
if (isset($path_parts[0]) && $path_parts[0] === 'api') {
    array_shift($path_parts);
}

// Route to appropriate endpoint
try {
    if (empty($path_parts) || empty($path_parts[0])) {
        // API root - return API info
        successResponse([
            'name' => 'NFC Card Store API',
            'version' => '1.0.0',
            'description' => 'Complete API for NFC Card Store e-commerce platform',
            'endpoints' => [
                'products' => '/api/products',
                'orders' => '/api/orders',
                'customers' => '/api/customers',
                'categories' => '/api/categories',
                'faq' => '/api/faq',
                'contact' => '/api/contact',
                'settings' => '/api/settings',
                'shipping' => '/api/shipping',
                'coupons' => '/api/coupons',
                'reviews' => '/api/reviews',
                'newsletter' => '/api/newsletter',
                'stats' => '/api/stats'
            ],
            'database' => 'digital_zin',
            'timestamp' => date('Y-m-d H:i:s')
        ], "NFC Card Store API v1.0.0");
    }
    
    $endpoint = $path_parts[0];
    
    switch ($endpoint) {
        case 'products':
            require_once 'endpoints/products.php';
            break;
            
        case 'orders':
            require_once 'endpoints/orders.php';
            break;
            
        case 'customers':
            require_once 'endpoints/customers.php';
            break;
            
        case 'categories':
        case 'settings':
        case 'shipping':
        case 'coupons':
        case 'reviews':
        case 'newsletter':
        case 'stats':
            require_once 'endpoints/general.php';
            break;
            
        case 'faq':
        case 'contact':
            require_once 'endpoints/support.php';
            break;
            
        case 'health':
            // Health check endpoint
            checkApiHealth();
            break;
            
        default:
            errorResponse("Endpoint not found: /{$endpoint}", 404);
            break;
    }
    
} catch (Exception $e) {
    error_log("API Router Error: " . $e->getMessage());
    errorResponse("Internal server error", 500);
}

/**
 * API Health Check
 */
function checkApiHealth() {
    try {
        $database = new Database();
        $db = $database->getConnection();
        
        // Test database connection
        $test_query = "SELECT 1 as test";
        $stmt = $db->prepare($test_query);
        $stmt->execute();
        $result = $stmt->fetch();
        
        if ($result['test'] == 1) {
            $health = [
                'status' => 'healthy',
                'database' => 'connected',
                'timestamp' => date('Y-m-d H:i:s'),
                'version' => '1.0.0'
            ];
            
            // Check table existence
            $tables_to_check = [
                'products', 'orders', 'customers', 'categories', 
                'faq', 'contact_messages', 'site_settings'
            ];
            
            $health['tables'] = [];
            foreach ($tables_to_check as $table) {
                $check_query = "SHOW TABLES LIKE '{$table}'";
                $check_stmt = $db->prepare($check_query);
                $check_stmt->execute();
                $health['tables'][$table] = $check_stmt->rowCount() > 0 ? 'exists' : 'missing';
            }
            
            successResponse($health, "API is healthy");
        } else {
            errorResponse("Database connection test failed", 500);
        }
        
    } catch (Exception $e) {
        errorResponse("API health check failed: " . $e->getMessage(), 500);
    }
}
?>

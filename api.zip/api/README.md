# NFC Card Store API Documentation

A complete PHP REST API for the NFC Card Store e-commerce platform with the `digital_zin` database.

## Database Configuration

- **Database Name**: `digital_zin`
- **Username**: `digital_zin`
- **Password**: `digital_zin`
- **Host**: `localhost`

## Base URL

```
http://your-domain.com/api/
```

## API Endpoints

### 🛍️ Products

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/products` | Get all products with filtering |
| `GET` | `/api/products/{id}` | Get single product by ID or slug |
| `POST` | `/api/products` | Create new product |
| `PUT` | `/api/products/{id}` | Update product |
| `DELETE` | `/api/products/{id}` | Delete product (soft delete) |

**Query Parameters for GET /products:**
- `category` - Filter by category ID
- `featured` - Filter featured products (true/false)
- `in_stock` - Filter by stock status (true/false)
- `min_price` - Minimum price filter
- `max_price` - Maximum price filter
- `search` - Search in name/description
- `sort` - Sort field (name, price, rating, created_at)
- `order` - Sort order (ASC, DESC)
- `page` - Page number
- `limit` - Items per page

**Example Requests:**
```bash
# Get all products
GET /api/products

# Get featured products
GET /api/products?featured=true

# Search products
GET /api/products?search=business+card

# Get products by category
GET /api/products?category=1

# Get single product
GET /api/products/1
GET /api/products/premium-black-nfc-business-card
```

### 📦 Orders

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/orders` | Get all orders with filtering |
| `GET` | `/api/orders/{id}` | Get order by ID or order number |
| `POST` | `/api/orders` | Create new order |
| `POST` | `/api/orders/track` | Track order by order number |
| `PUT` | `/api/orders/{id}` | Update order status |

**Query Parameters for GET /orders:**
- `customer_id` - Filter by customer
- `status` - Filter by order status
- `payment_status` - Filter by payment status
- `start_date` - Date range start
- `end_date` - Date range end
- `email` - Search by customer email

**Example Requests:**
```bash
# Get all orders
GET /api/orders

# Get orders by status
GET /api/orders?status=shipped

# Get customer orders
GET /api/orders?customer_id=cust-001

# Track order
POST /api/orders/track
{
  "order_number": "NFC2025001"
}

# Create order
POST /api/orders
{
  "customer_email": "customer@example.com",
  "items": [
    {
      "product_id": "1",
      "product_name": "Premium Black NFC Card",
      "quantity": 2,
      "unit_price": 29.99
    }
  ],
  "shipping_info": {
    "first_name": "John",
    "last_name": "Doe",
    "street_address": "123 Main St",
    "city": "New York",
    "state": "NY",
    "postal_code": "10001",
    "country": "United States"
  },
  "billing_info": { ... },
  "shipping_method_id": 1
}
```

### 👥 Customers

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/customers` | Get all customers |
| `GET` | `/api/customers/{id}` | Get customer by ID |
| `POST` | `/api/customers/register` | Register new customer |
| `POST` | `/api/customers/login` | Customer login |
| `POST` | `/api/customers/verify-email` | Verify email |
| `POST` | `/api/customers/forgot-password` | Forgot password |
| `POST` | `/api/customers/reset-password` | Reset password |
| `PUT` | `/api/customers/{id}` | Update customer |
| `DELETE` | `/api/customers/{id}` | Delete customer |

**Example Requests:**
```bash
# Register customer
POST /api/customers/register
{
  "first_name": "John",
  "last_name": "Doe",
  "email": "john@example.com",
  "password": "securepassword",
  "phone": "+1-555-0123"
}

# Login
POST /api/customers/login
{
  "email": "john@example.com",
  "password": "securepassword"
}
```

### 📚 Categories

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/categories` | Get all categories |
| `GET` | `/api/categories/{id}` | Get category by ID |
| `POST` | `/api/categories` | Create category |
| `PUT` | `/api/categories/{id}` | Update category |
| `DELETE` | `/api/categories/{id}` | Delete category |

### ❓ FAQ

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/faq` | Get all FAQs grouped by category |
| `GET` | `/api/faq/{id}` | Get single FAQ |
| `POST` | `/api/faq` | Create FAQ |
| `PUT` | `/api/faq/{id}` | Update FAQ |
| `DELETE` | `/api/faq/{id}` | Delete FAQ |

**Query Parameters:**
- `category` - Filter by FAQ category
- `search` - Search in questions/answers

### 💬 Contact

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/contact` | Get all contact messages |
| `GET` | `/api/contact/{id}` | Get contact message by ID |
| `POST` | `/api/contact` | Submit contact message |
| `PUT` | `/api/contact/{id}` | Update message status (admin) |
| `DELETE` | `/api/contact/{id}` | Delete message |

**Example Request:**
```bash
# Submit contact message
POST /api/contact
{
  "name": "John Doe",
  "email": "john@example.com",
  "subject": "Product Inquiry",
  "message": "I need more information about bulk orders.",
  "type": "sales"
}
```

### ⭐ Reviews

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/reviews` | Get all reviews |
| `POST` | `/api/reviews` | Create product review |
| `PUT` | `/api/reviews/{id}` | Update review (admin) |

**Example Request:**
```bash
# Create review
POST /api/reviews
{
  "product_id": "1",
  "customer_name": "John Doe",
  "customer_email": "john@example.com",
  "rating": 5,
  "title": "Excellent quality!",
  "review_text": "Love this NFC card!"
}
```

### 🎟️ Coupons

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/coupons` | Get all coupons |
| `POST` | `/api/coupons/validate` | Validate coupon code |
| `POST` | `/api/coupons` | Create coupon |
| `PUT` | `/api/coupons/{id}` | Update coupon |

**Example Request:**
```bash
# Validate coupon
POST /api/coupons/validate
{
  "code": "WELCOME10",
  "order_total": 99.98
}
```

### 🚚 Shipping

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/shipping` | Get all shipping methods |
| `POST` | `/api/shipping` | Create shipping method |
| `PUT` | `/api/shipping/{id}` | Update shipping method |

### ⚙️ Settings

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/settings` | Get all settings |
| `GET` | `/api/settings/{key}` | Get setting by key |
| `POST` | `/api/settings` | Create/update setting |

**Query Parameters:**
- `public=true` - Get only public settings

### 📧 Newsletter

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/newsletter/subscribe` | Subscribe to newsletter |
| `POST` | `/api/newsletter/unsubscribe` | Unsubscribe from newsletter |

### 📊 Statistics

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/stats/dashboard` | Get dashboard statistics |
| `GET` | `/api/stats/sales` | Get sales statistics |
| `GET` | `/api/stats/products` | Get product statistics |
| `GET` | `/api/stats/customers` | Get customer statistics |

### 🏥 Health Check

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/health` | API and database health check |

## Response Format

All API responses follow this format:

```json
{
  "success": true,
  "message": "Success message",
  "data": { ... }
}
```

**Error Response:**
```json
{
  "success": false,
  "message": "Error message",
  "code": "ERROR_CODE"
}
```

## Pagination

List endpoints support pagination:

```json
{
  "success": true,
  "message": "Data retrieved successfully",
  "data": {
    "data": [ ... ],
    "pagination": {
      "current_page": 1,
      "total_pages": 5,
      "per_page": 20,
      "total_items": 95,
      "has_next": true,
      "has_prev": false
    }
  }
}
```

## Authentication

Currently, the API uses simple session tokens for customer authentication. In production, implement proper JWT tokens or OAuth.

## Error Codes

- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `405` - Method Not Allowed
- `409` - Conflict (duplicate data)
- `500` - Internal Server Error

## Usage Examples

### Frontend Integration (JavaScript)

```javascript
// Get all products
const products = await fetch('/api/products')
  .then(response => response.json());

// Create order
const order = await fetch('/api/orders', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    customer_email: 'customer@example.com',
    items: [...],
    shipping_info: {...}
  })
}).then(response => response.json());

// Submit contact form
const message = await fetch('/api/contact', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    name: 'John Doe',
    email: 'john@example.com',
    subject: 'Inquiry',
    message: 'Hello...'
  })
}).then(response => response.json());
```

### PHP Integration

```php
// Get products
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, 'http://your-domain.com/api/products');
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($curl);
$products = json_decode($response, true);
curl_close($curl);
```

## Setup Instructions

1. **Database Setup:**
   ```sql
   CREATE DATABASE digital_zin;
   USE digital_zin;
   -- Import the nfc_card_store.sql file
   ```

2. **Configure Database:**
   - Update `api/config/database.php` with your database credentials
   - Database name: `digital_zin`
   - Username: `digital_zin`
   - Password: `digital_zin`

3. **Web Server:**
   - Place API files in your web server directory
   - Ensure URL rewriting is enabled for clean URLs
   - Set proper file permissions

4. **Test API:**
   ```bash
   curl http://your-domain.com/api/health
   ```

## Security Notes

- Enable HTTPS in production
- Implement proper authentication/authorization
- Validate and sanitize all inputs
- Use prepared statements (already implemented)
- Set up proper CORS policies
- Monitor API usage and implement rate limiting

## Production Deployment

1. Disable error display in `database.php`
2. Set up proper logging
3. Implement caching (Redis/Memcached)
4. Use environment variables for sensitive data
5. Set up monitoring and alerts
6. Implement backup strategies

The API is now ready to power your NFC Card Store website with full CRUD operations for all entities!
